---
name: KhipuNet Design System
colors:
  surface: '#f7f9fb'
  surface-dim: '#d8dadc'
  surface-bright: '#f7f9fb'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f2f4f6'
  surface-container: '#eceef0'
  surface-container-high: '#e6e8ea'
  surface-container-highest: '#e0e3e5'
  on-surface: '#191c1e'
  on-surface-variant: '#45464d'
  inverse-surface: '#2d3133'
  inverse-on-surface: '#eff1f3'
  outline: '#76777d'
  outline-variant: '#c6c6cd'
  surface-tint: '#565e74'
  primary: '#000000'
  on-primary: '#ffffff'
  primary-container: '#131b2e'
  on-primary-container: '#7c839b'
  inverse-primary: '#bec6e0'
  secondary: '#505f76'
  on-secondary: '#ffffff'
  secondary-container: '#d0e1fb'
  on-secondary-container: '#54647a'
  tertiary: '#000000'
  on-tertiary: '#ffffff'
  tertiary-container: '#271901'
  on-tertiary-container: '#98805d'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#dae2fd'
  primary-fixed-dim: '#bec6e0'
  on-primary-fixed: '#131b2e'
  on-primary-fixed-variant: '#3f465c'
  secondary-fixed: '#d3e4fe'
  secondary-fixed-dim: '#b7c8e1'
  on-secondary-fixed: '#0b1c30'
  on-secondary-fixed-variant: '#38485d'
  tertiary-fixed: '#fcdeb5'
  tertiary-fixed-dim: '#dec29a'
  on-tertiary-fixed: '#271901'
  on-tertiary-fixed-variant: '#574425'
  background: '#f7f9fb'
  on-background: '#191c1e'
  surface-variant: '#e0e3e5'
typography:
  display-lg:
    fontFamily: Hanken Grotesk
    fontSize: 48px
    fontWeight: '700'
    lineHeight: 56px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Hanken Grotesk
    fontSize: 32px
    fontWeight: '600'
    lineHeight: 40px
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Hanken Grotesk
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
  body-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  label-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.05em
  headline-lg-mobile:
    fontFamily: Hanken Grotesk
    fontSize: 28px
    fontWeight: '600'
    lineHeight: 36px
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  unit: 4px
  container-max: 1440px
  gutter: 24px
  margin-mobile: 16px
  margin-desktop: 40px
  sidebar-width: 360px
---

## Brand & Style

The design system is built for a high-end, institutional platform that visualizes complex technological networks. It draws inspiration from the "Khipu"—the ancient Andean recording device—translating the concept of connected nodes and threads into a modern, digital interface.

The brand personality is **authoritative yet exploratory**. It balances the rigor of government institutionalism with the innovation of a technology transfer network. The visual style follows a **Modern Corporate** aesthetic with strong **Editorial** influences: ample whitespace, sophisticated typography, and a "light-mode-first" philosophy that feels breathable and premium. The UI stays out of the way of the data, acting as a refined gallery for the interactive relationship maps.

## Colors

The palette is anchored by a deep slate primary and a series of "Warm Off-Whites" and "Cool Grays" for the background and surfaces. This creates an academic, high-end feel. 

Functional color is reserved for the **Product Chains**. These accents are vibrant enough to distinguish nodes on a complex map but are calibrated to maintain a professional harmony when viewed together. 
- **Backgrounds:** Use `#F8FAFC` for the main canvas to reduce eye strain during long analytical sessions.
- **Surface:** Use `#FFFFFF` for cards and floating panels to create clear separation.
- **Accents:** Use the Product Chain colors for node borders, connection lines (when filtered), and category chips.

## Typography

This design system uses **Hanken Grotesk** for headings to provide a sharp, contemporary "tech-institutional" edge. **Inter** is used for body text and UI labels due to its exceptional legibility in data-dense environments.

The hierarchy is intentionally dramatic. Titles are bold and tight-tracked to command attention, while body text remains airy. Metadata and legends use uppercase labels with slight letter spacing to differentiate technical data from narrative descriptions.

## Layout & Spacing

The layout utilizes a **hybrid-fluid model**. The main relationship map (the Canvas) is fully fluid, expanding to fill all available viewport space. Overlaid on this canvas is a fixed-width **Information Panel** (360px) on the left or right, designed with an editorial feel—similar to a research paper or a premium blog.

Margins are generous (40px on desktop) to reinforce the "High-End" feel. A 4px baseline grid ensures consistent vertical rhythm. Components within the information panel follow a single-column stack to maintain clarity.

## Elevation & Depth

Hierarchy is established through **Tonal Layers** and **Soft Ambient Shadows**. 
1. **Level 0 (Canvas):** The base layer where the map lives. Flat `#F8FAFC`.
2. **Level 1 (Cards/Panels):** Floating white surfaces. Use a very soft, diffused shadow: `0px 4px 20px rgba(15, 23, 42, 0.05)`.
3. **Level 2 (Popovers/Tooltips):** Used for node details on hover. Use a slightly more defined shadow and a subtle 1px border in `#E2E8F0` to ensure separation from Level 1.

Avoid heavy blurs or glassmorphism to keep the interface feeling "stable" and "institutional."

## Shapes

The shape language is **Rounded (0.5rem / 8px)**. This softens the technical nature of the network map, making the data feel more approachable and modern. 
- **Nodes:** Circular for entities (Universities, Startups) to maintain the "Kumu-style" graph aesthetic.
- **Cards/Buttons:** 8px corner radius.
- **Status Chips:** Full pill-shape for high-contrast categorizing.

## Components

### Interactive Nodes
Nodes should have a 2px stroke. On hover, the stroke thickness doubles, and the node emits a soft glow using its assigned Product Chain color.

### Information Cards
Cards within the sidebar use a 1px border (`#E2E8F0`) and no shadow when "embedded," but a shadow when "floating." Typography inside cards should lead with `label-sm` to categorize the content (e.g., "PRIVATE CITE").

### Legend Icons
Use geometric glyphs within small circles:
- **University:** Book/Graduation cap icon.
- **Startup:** Rocket/Lightning icon.
- **Fund:** Currency/Scale icon.
- **CITE:** Laboratory/Gear icon.

### Buttons
Primary buttons use the deep Slate (`#0F172A`) with white text. Secondary buttons are "Ghost" style—transparent with a subtle border—to keep the UI light.

### Micro-interactions
Transitions between map states (filtering a product chain) should use a `cubic-bezier(0.4, 0, 0.2, 1)` easing over 300ms to feel fluid and organic, mirroring the movement of a physical string network.